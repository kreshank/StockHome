# Install OCaml
Follow the instructions to download OCaml from this [installation guide](https://cs3110.github.io/textbook/chapters/preface/install.html).

# Dependencies
As of now, this program has no OPAM dependencies. 

# Running the Code
To run the code, simply run `make display` in the terminal, then follow the prompts from there. 